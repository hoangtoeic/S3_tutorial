
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'hoangtoeic',
  applicationName: 'myexcels3project',
  appUid: 'cX7brlq0vhy57jnPNV',
  orgUid: 'f1faa838-974b-4bda-9a9f-afbaa3a9bdb3',
  deploymentUid: '04ad7aaf-3222-4f5a-abea-3b33a1c23a3c',
  serviceName: 'myexcels3project',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.5.4',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'myexcels3project-dev-hello', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.hello, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}